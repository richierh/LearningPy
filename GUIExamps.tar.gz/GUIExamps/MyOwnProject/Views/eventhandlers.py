#!usr/bin/env python
# -*- coding: utf-8 -*-

class koleksievent(RangkaUtama):
    
    def __init__(self,*args,**kwargs):
        RangkaUtama.__init__("",*args,**kwargs)
    def bukarangka1(self, event):  # wxGlade: RangkaUtama.<event_handler>
        print("Event handler 'bukarangka1' now is goitn to be here implemented!")
