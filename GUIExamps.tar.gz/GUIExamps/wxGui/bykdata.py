#!usr/bin/python


class datasiswa():
    def __init__(self):
        print "hallo"
    def go(self,kay):
        print "okay "+kay

c = datasiswa()
c.go("siapa")
